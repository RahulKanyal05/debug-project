import AuthForm from "@/components/auth/AuthForm";

const Page = () => {
  return <AuthForm type="sign-in" />;
};

export default Page;
