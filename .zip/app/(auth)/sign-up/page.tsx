import AuthForm from "@/components/auth/AuthForm";

const Page = () => {
  return <AuthForm type="sign-up" />;
};

export default Page;
